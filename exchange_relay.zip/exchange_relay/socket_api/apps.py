from django.apps import AppConfig


class SocketApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'socket_api'
